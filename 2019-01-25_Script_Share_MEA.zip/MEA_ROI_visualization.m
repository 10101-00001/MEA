%% writen and developed by Uwe Altmann 
%
% For Motion Energy Analysis regions of interest (ROI) must be defined. 
% The script MEA_ROI_freehand allow the definition of ROI by drawing the
% ROI based on a video frame.
% With this script the defined ROI can be visualizated. The script needs
% the video file and the MAT file in which the ROI for this video are
% stored.


function [] = MEA_ROI_visualization(video_file_name, frame_no)

    % *** proof input ***************************************************
    if nargin < 1,

        disp(' ')
        disp('Please select the video file of which the ROI should be visualizated.')
        
        [filename, PathName, ~] = uigetfile('*.avi');
    
        video_file_name = [PathName filename];        
        
    end
   
    

    % *** load video ****************************************************
    
    disp(' ')
    disp(['Open video: ' video_file_name ]);
    
    mov = VideoReader( video_file_name );

    disp(['Video size: ', num2str(mov.Height), ' x ', num2str(mov.Width) ]);
    disp(['Number of frame: ', num2str( mov.numberOfFrames ) ]);    
    disp(['Frame rate: ', num2str(mov.FrameRate) ]);
    

    
    % *** load MAT file with ROI information ****************************
    
    [video_file_path, video_file_name2, ~] = fileparts(video_file_name); 
    
    MAT_file_name = [ video_file_path '\' video_file_name2 '_rois.mat' ];
    
    disp(' ')
    disp(['Open MAT file: ' MAT_file_name ]);
    
    load(MAT_file_name);
  
    
    
    
    % *** load example frame********************************************
    
    if nargin < 2,        
        frame_no = round( 0.1 * mov.numberOfFrames );
        
        disp(' ')
        disp(['For drawing ROI, no reference video frame was specified. The default (video duration / 10 = ' num2str(frame_no) ') is used.'])
        
    end
    
    
    if mov.numberOfFrames < frame_no,        
        frame_no = round( 0.1 * mov.numberOfFrames );
        
        disp(' ')
        disp(['The video duration is shorter than expected. Reference video frame is set to frame no. ' ...
              num2str(frame_no) '.'])    
    end
        

    frame_1 = rgb2gray( read( mov, frame_no) );
    

    
    % find edge of ROI **************************************************
    
    roi1_edge = edge( roi1 );
    roi2_edge = edge( roi2 );
    roi3_edge = edge( roi3 );
    roi4_edge = edge( roi4 );
    roi5_edge = edge( roi5 );
    roi6_edge = edge( roi6 );
    
    roi_edge = roi1_edge | roi2_edge | roi3_edge | ...
               roi4_edge | roi5_edge | roi6_edge ; % merge all ROI
    
    
    
    
    % show video frame whereby background ROI marked *********************

    disp(' ')
    disp('Plot videoframe including eadges of all ROI.')
    disp(' ')
    
    
    % mit Falschfarben
    figure(1);
    imshowpair( frame_1, roi_edge);
    
    
    % als grauer Rahmen

    frame_1b = frame_1; 
    frame_1b( roi_edge==1 ) = 125; % 0 = schwarz, 255 = wei�
    
    figure(2);
    imshow( frame_1b)
    
    
end % function
    
    
    
    
    
    
    
    
    
    
    