%% writen and developed by Uwe Altmann and D�sir�e Sch�nherr (n�e Thielemann)

% Before you run this script, please start "MEA_ROI_freehand_v04.m"
% to mark the regions of interest (ROI) which should be analysed.
% Output file of "MEA_ROI_freehand.m" is 
% required to run this script without errors.

% input parameter:
% directory_name = path of the video files
% video_format = format of videos, e.g. 'avi'
% cut off = cut off for meaningful pixel changes

% Output are files. A file contains a matrix with:
% 1. column: ME of left person upper body
% 2. column: ME of right person upper body
% 3. column: ME of left noise ROI
% 4. column: ME of right noise ROI
% 5. column: ME of left person head
% 6. column: ME of right person head
% the line refers to the video frame, in line 23 for example are the 
% motion energy values saved which were computed with frame 23 and 24.

function [] = MEA_and_preprocessing_of_a_directory(directory_name, video_format, cut_off)


    % check for cut off value
    if nargin<3 || isempty(cut_off) ,

        disp(' ')
        disp('The cut off value is not given. The default value (12) is used.')
        
        cut_off = 12; % default is 12
        
    elseif ~(cut_off >= 0  &&  cut_off < 256),
        
        disp(' ')
        disp('The cut off value is out of range. The default value (12) is used.')
        
        cut_off = 12; % default is 12
        
    end
    
    
    % check parameter for video format
    if nargin<2 || isempty(video_format) || ~isa(video_format, 'char'),
        disp(' ')
        disp('Video format is not given respectively is not a string. The default value (avi) is used.')
        
        video_format = 'avi';  % default is 'avi'
        
    end
    
    
    % check input arguments: file name? If no, select with file browser
    if nargin<1 || isempty(directory_name) ,

        disp(' ')
        disp('Please select the directory in which the video files and the corresponding MAT file (with ROI informations) are stored.')
        
        directory_name = uigetdir;
        
    else
    
        if exist( directory_name, 'dir') ~= 7
            
            error(['The specified directory (' directory_name ...
                   ') is not a folder or does not exist.'])
        
        end
        
    end
    
    disp(' ')
    disp(['Selected directory is ' directory_name])
    
    
    
    % *** create a list with video files ********************************

    Names = dir( fullfile(directory_name, ['*.' video_format]) );
    Names = {Names.name}';
    Names = fullfile(directory_name, Names);

    n_videos = length(Names);
    
    disp(' ')
    disp(['Found ' num2str(n_videos) ' video files.'])
    
    
    % *** MEA and pre-processing steps for each video file **************
    for n = 1:n_videos,
        
        MEA_and_preprocessing_of_a_video( Names{n} )
        
    end % for
    
    disp(' ')
    disp(['Analysis of video files in the directory ' directory_name ...
          ' finished. Please check for warnings in the log-file. ' ...
          'A warning is given when a MAT file (with informations about ' ...
          'ROI) is not found for the video file.'])
    
end % function