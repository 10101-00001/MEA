%% writen and developed by Uwe Altmann 
% version 2.0 - with caption of ROI
%
% For Motion Energy Analysis regions of interest (ROI) must be defined. 
% The script MEA_ROI_freehand allow the definition of ROI by drawing the
% ROI based on a video frame.
% With this script the defined ROI can be visualizated. The script needs
% the video file and the MAT file in which the ROI for this video are
% stored.
% Each ROI is labeled. The label is written in the center of corresponding
% ROI. A line marks a body ROI and a dotted line a head ROI.
% Note that the video frame is always converted from color to gray scale so
% that the red respectively blue border of ROI is more highlighted.


function [] = MEA_ROI_visualization_v02(video_file_name, save_plot, frame_no)

    % *** proof input ***************************************************
    if nargin < 1,

        disp(' ')
        disp('Please select the video file of which the ROI should be visualizated.')
        
        [filename, PathName, ~] = uigetfile('*.avi');
    
        video_file_name = [PathName filename];        
        
    end
   
    
    if nargin < 2 || ~isa(save_plot, 'logical'),
        
        save_plot = true; % true -> figure is saved on HD, false -> figure is no saved
        
    end
    

    % *** load video ****************************************************
    
    disp(' ')
    disp(['Open video: ' video_file_name ]);
    
    mov = VideoReader( video_file_name );

    disp(['Video size: ', num2str(mov.Height), ' x ', num2str(mov.Width) ]);
    disp(['Number of frame: ', num2str( mov.numberOfFrames ) ]);    
    disp(['Frame rate: ', num2str(mov.FrameRate) ]);
    

    
    % *** load MAT file with ROI information ****************************
    
    [video_file_path, video_file_name2, ~] = fileparts(video_file_name); 
    
    MAT_file_name = [ video_file_path '\' video_file_name2 '_rois.mat' ];
    
    disp(' ')
    disp(['Open MAT file: ' MAT_file_name ]);
    
    load(MAT_file_name);
  
    
    
    
    % *** load example frame********************************************
    
    if nargin < 3,        
        frame_no = round( 0.1 * mov.numberOfFrames );
        
        disp(' ')
        disp(['For drawing ROI, no reference video frame was specified. The default (video duration / 10 = ' num2str(frame_no) ') is used.'])
        
    end
    
    
    if mov.numberOfFrames < frame_no,        
        frame_no = round( 0.1 * mov.numberOfFrames );
        
        disp(' ')
        disp(['The video duration is shorter than expected. Reference video frame is set to frame no. ' ...
              num2str(frame_no) '.'])    
    end
        

    frame_1 = rgb2gray( read( mov, frame_no) );
    
    
    % center of ROI (for captions) **************************************
    ROI_centers = zeros(6,2);
    
    s =  regionprops( roi1, 'centroid');
    ROI_centers(1,1) = s.Centroid(1); ROI_centers(1,2) = s.Centroid(2); 
    
    s =  regionprops( roi2, 'centroid');
    ROI_centers(2,1) = s.Centroid(1); ROI_centers(2,2) = s.Centroid(2);
    
    s =  regionprops( roi5, 'centroid');
    ROI_centers(5,1) = s.Centroid(1); ROI_centers(5,2) = s.Centroid(2); 

    s =  regionprops( roi6, 'centroid');
    ROI_centers(6,1) = s.Centroid(1); ROI_centers(6,2) = s.Centroid(2); 

    
    
    % show video frame whereby background ROI marked ********************

    disp(' ')
    disp('Plot videoframe including eadges of all ROI.')
    disp(' ')
    
    % plot video frame
    fig1 = figure(1);
    imshow( frame_1);
    
    hold on;
    
    % write the name of ROI 
    
    text(ROI_centers(1,1), ROI_centers(1,2), '{\bfbody} person {\bf1} (patient)',   ...
        'Color', 'red', 'HorizontalAlignment', 'center', 'Margin', 1, ...
        'BackgroundColor', 'white');
    
    text(ROI_centers(2,1), ROI_centers(2,2), '{\bfbody} person {\bf2} (therapist)',   ...
        'Color', 'blue', 'HorizontalAlignment', 'center', 'Margin', 1, ...
        'BackgroundColor', 'white' );
    
    text(ROI_centers(5,1), ROI_centers(5,2), '{\bfhead} person {\bf1} (patient)',   ...
        'Color', 'red', 'HorizontalAlignment', 'center', 'Margin', 1, ...
        'BackgroundColor', 'white');
    
    text(ROI_centers(6,1), ROI_centers(6,2), '{\bfhead} person {\bf2} (therapist)',   ...
        'Color', 'blue', 'HorizontalAlignment', 'center', 'Margin', 1, ...
        'BackgroundColor', 'white' );
    
    
    % show edge of ROI
    
    visboundaries(roi1, 'Color', 'r', 'LineStyle', '-'); % Pat body
    visboundaries(roi2, 'Color', 'b', 'LineStyle', '-'); % Ther body
    visboundaries(roi5, 'Color', 'r', 'LineStyle', ':'); % Pat head
    visboundaries(roi6, 'Color', 'b', 'LineStyle', ':'); % Ther head
    
    
    % save plot ********************************************************
    
    if save_plot == true,
        
        saveas(fig1, [ video_file_path '\' video_file_name2 '_ROI_check' ], 'png')
        
    end % if
    
        
end % function
    
    
    
    
    
    
    
    
    
    
    